# ⚔️ Solo Leveling Fitness — Hunter RPG Training System

A gamified fitness tracker inspired by Solo Leveling and RPG level-up systems.

## 🚀 Deploy to Vercel (3 steps)

### Option A — Vercel CLI
```bash
npm install
npm run build
npx vercel --prod
```

### Option B — Vercel Dashboard
1. Push this folder to a GitHub repository
2. Go to [vercel.com](https://vercel.com) → New Project
3. Import your repo — Vercel auto-detects Vite ✅
4. Click **Deploy**

### Option C — Drag & Drop
1. Run `npm install && npm run build`
2. Drag the `dist/` folder to [vercel.com/new](https://vercel.com/new)

---

## 💻 Local Development

```bash
npm install
npm run dev
```

Open [http://localhost:5173](http://localhost:5173)

## 🏗️ Build for Production

```bash
npm run build
npm run preview   # preview the production build locally
```

---

## 🎮 System Features

- **6 Ranks**: E → D → C → B → A → S
- **XP & Level system** with scaling formula
- **5 Player Stats**: Strength, Endurance, Agility, Discipline, Mental Focus
- **Daily Missions**: Push-ups, Squats, Plank, Run, Flexibility
- **Boss Battles**: Weekly challenge events
- **Skill Tree**: 5 unlockable passive abilities
- **Week 1 Plan**: Full E-Rank beginner training arc
- **Streak System**: Streak multipliers and bonuses
- **Particle effects** on level-up

---

Built with React 18 + Vite 5
